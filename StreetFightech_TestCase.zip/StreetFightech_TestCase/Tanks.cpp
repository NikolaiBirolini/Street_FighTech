#include "Tanks.hh"

using namespace std;

Tanks::Tanks(string nom, string classe,int Sante, int ptAttaque, int ptSoin) : Personnages(nom,classe,ptSoin,ptAttaque,Sante){
	
}

Tanks::~Tanks(){
	
}
