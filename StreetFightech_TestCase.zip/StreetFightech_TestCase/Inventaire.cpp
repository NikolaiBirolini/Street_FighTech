#include "Inventaire.hh"

using namespace std;



Inventaire::Inventaire(string nom,int pA, int pS, int pV):nomItem(nom),pA(pA), pS(pS), pV(pV){

}

Inventaire::~Inventaire(){
	
}


//Fonction affichant les informations de l'arme
void Inventaire::printItemInfos(){
	cout << "Nom : "<< getNomItem()<<endl;
	cout << "Points d'attaque : "<< getpA()<<endl;
	cout << "Points de Santé : "<< getpS()<<endl;
	cout << "Points de vie : "<< getpV()<<endl;
}