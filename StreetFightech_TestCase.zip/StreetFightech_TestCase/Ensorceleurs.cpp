#include "Ensorceleurs.hh"

using namespace std;

Ensorceleurs::Ensorceleurs(string nom) : Soigneurs(nom,"Ensorceleurs",90,rand()%11+35){


}

Ensorceleurs::~Ensorceleurs(){
	
}

void Ensorceleurs::Soigner(Personnages &cible){
	cible.recevoirSoin(getPtSoin());
	cout<<"Resiste ! Prouve que tu existes !"<<endl;
}