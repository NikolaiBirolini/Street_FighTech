#pragma once
#include <iostream>
#include <cstdlib>
#include "Inventaire.hh"

using namespace std;

//Classe iteme
class Famas : public Inventaire {

public:
	Famas();
	~Famas(); 

protected:

};
