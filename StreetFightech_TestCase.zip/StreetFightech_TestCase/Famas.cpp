#include "Famas.hh"

using namespace std;

Famas::Famas() : Inventaire("Famas",10,0,15){


}

Famas::~Famas(){
	
}
