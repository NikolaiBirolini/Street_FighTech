#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class Inventaire{

protected:

	string nomItem;
	int pA;//Points d'Attaque
	int pS; //Points de soin
	int pV; //Points de vie


public :
	Inventaire(string nom,int pA, int pS, int pV);
	~Inventaire();

	void printItemInfos();//Fonction donnant les informations de l'arme

	//Getteur
	string getNomItem() const {return nomItem;}
	int getpA()const {return pA;}
	int getpS() const {return pS;}
	int getpV() const {return pV;}

};