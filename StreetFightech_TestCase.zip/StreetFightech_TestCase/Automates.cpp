#include "Automates.hh"

using namespace std;

Automates::Automates(string nom) : Tanks(nom,"Automates",200,15,10){


}

Automates::~Automates(){
	
}

void Automates::Attaque(Personnages &cible){
	cible.recevoirDegat(getPtAttaque());
	cout<<"Boom boom"<<endl;
}

void Automates::Soigner(Personnages &cible){

	cout << "Heal !!!"<<endl;
	cible.recevoirSoin(getPtSoin());
}
