#pragma once
#include <iostream>
#include <cstdlib>
#include "Tanks.hh"

using namespace std;
//Classe personnage
class Blindes : public Tanks {

public:
	Blindes(string nom);
	virtual ~Blindes();
	virtual void Attaque(Personnages &cible); 
	virtual void Soigner(Personnages &cible);

protected:
	string classe = "Blindes";

};
