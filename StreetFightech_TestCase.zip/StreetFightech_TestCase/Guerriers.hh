#pragma once 
#include <iostream>
#include <cstdlib>
#include "Personnages.hh"


using namespace std;

class Guerriers : public Personnages {

public:
	Guerriers(string nom, string classe, int Sante, int ptAttaque);
	~Guerriers();
	virtual void Soigner(Personnages &cible);

protected:
	int ptAttaque;
	int ptSoin;
};