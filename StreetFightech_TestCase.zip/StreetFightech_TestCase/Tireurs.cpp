#include "Tireurs.hh"

using namespace std;

Tireurs::Tireurs(string nom) : Guerriers(nom,"Tireurs",70,40){


}

Tireurs::~Tireurs(){
	
}

void Tireurs::Attaque(Personnages &cible){
	cible.recevoirDegat(getPtAttaque());
	cout<<"Pan pan"<<endl;
}