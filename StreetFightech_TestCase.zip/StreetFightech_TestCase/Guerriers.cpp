#include "Guerriers.hh"

using namespace std;

Guerriers::Guerriers(string nom, string classe, int Sante, int ptAttaque) : Personnages(nom,classe,0,ptAttaque,Sante){
	
}

Guerriers::~Guerriers(){
	
}

void Guerriers::Soigner(Personnages &cible){

	cout << "Impossible de soigner"<<endl;
}
