#include "AmasChair.hh"

using namespace std;

AmasChair::AmasChair(string nom) : Tanks(nom,"AmasChair",180,rand()%6+15,rand()%6+15){


}

AmasChair::~AmasChair(){
	
}

void AmasChair::Attaque(Personnages &cible){
	cible.recevoirDegat(getPtAttaque());
	cout<<"Boom boom"<<endl;
}

void AmasChair::Soigner(Personnages &cible){

	cout << "Heal !!!"<<endl;
	cible.recevoirSoin(getPtSoin());
}
