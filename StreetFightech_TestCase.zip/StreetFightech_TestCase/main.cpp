#include <iostream>
#include "Terminators.hh"
#include "Tireurs.hh"
#include "Maudits.hh"
#include "Blindes.hh"
#include "Docteurs.hh"
#include "Ensorceleurs.hh"
#include "Nanites.hh"
#include "Famas.hh"
#include "Deck.hh"
//#include <SFML/Graphics.hpp>
//#include "BoutonAttaquer.hh"

//using namespace sf;
using namespace std;

//Programme main test

int main(){

	//Terminators a("Mikasa");
	Tireurs b("Jean");
	Maudits c("Eren");
	Nanites h("Historia");
	Terminators e("Erwin");
	//Docteurs f("Bertolto");
	Ensorceleurs g("Annie");

	Terminators* z = new Terminators("Jean Paul");
	Terminators* a = new Terminators("Mikasa");

	Docteurs* f = new Docteurs("Bertolto");
	Docteurs* karl = new Docteurs("Karl");

	cout<<karl<<endl;

	Deck deck1;
	Deck deck2;


	deck1.ajouterDeck(z);
	deck2.ajouterDeck(f);

	cout<<deck1.getVecteur()[0]<<endl<<endl;


	cout<<z<<endl;
	cout<<endl<<endl;
	cout<<f<<endl;
	
	z->Attaque((*f));

	cout<<z<<endl;
	cout<<endl<<endl;
	cout<<f<<endl;


}