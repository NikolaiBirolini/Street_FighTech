#pragma once 
#include <iostream>
#include <cstdlib>
#include "Personnages.hh"


using namespace std;

class Soigneurs : public Personnages {

public:
	Soigneurs(string nom, string classe, int Sante, int ptSoin);
	~Soigneurs();
	virtual void Attaquer(Personnages &cible);

protected:
	int ptAttaque;
	int ptSoin;
};