#pragma once 
#include <iostream>
#include <cstdlib>
#include "Personnages.hh"


using namespace std;
//Classe personnage
class Tanks : public Personnages {

public:
	Tanks(string nom, string classe,int Sante, int ptAttaque, int ptSoin);
	~Tanks();

protected:
	int ptAttaque;
	int ptSoin;
};
