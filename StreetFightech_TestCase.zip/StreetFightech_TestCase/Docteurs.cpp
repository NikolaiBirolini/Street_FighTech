#include "Docteurs.hh"

using namespace std;

Docteurs::Docteurs(string nom) : Soigneurs(nom,"Docteurs",65,45){


}

Docteurs::~Docteurs(){
	
}

void Docteurs::Soigner(Personnages &cible){
	cible.recevoirSoin(getPtSoin());
	cout<<"Resiste ! Prouve que tu existes !"<<endl;
}