#pragma once
#include <iostream>
#include <cstdlib>
#include "Soigneurs.hh"

using namespace std;
//Classe personnage
class Nanites : public Soigneurs {

public:
	Nanites(string nom);
	virtual ~Nanites();
	virtual void Soigner(Personnages &cible); 


protected:
	string classe = "Nanites";

};

