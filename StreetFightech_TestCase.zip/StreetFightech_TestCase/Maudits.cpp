#include "Maudits.hh"

using namespace std;

Maudits::Maudits(string nom) : Guerriers(nom,"Maudits",60,rand()%6+55){


}

Maudits::~Maudits(){
	
}
void Maudits::Attaque(Personnages &cible){
	cible.recevoirDegat(getPtAttaque());
	cout<<"abat"<<endl;
}