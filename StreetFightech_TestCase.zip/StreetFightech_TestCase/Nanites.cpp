#include "Nanites.hh"

using namespace std;

Nanites::Nanites(string nom) : Soigneurs(nom,"Nanites",rand()%11+100,30){


}

Nanites::~Nanites(){
	
}

void Nanites::Soigner(Personnages &cible){
	cible.recevoirSoin(getPtSoin());
	cout<<"Resiste ! Prouve que tu existes !"<<endl;
}