#include "Personnages.hh"
#include <iostream>

using namespace std;

Personnages::Personnages(string nom,string classe, int ptSoin, int ptAttaque, int ptSante):nom(nom), classe(classe),ptSoin(ptSoin), ptAttaque(ptAttaque), ptSante(ptSante){

	distance =rand()%50+10; //Distance entre 10 et 60
}

Personnages::~Personnages(){
	
}

void Personnages::recevoirDegat(int degats){
	cout<<"Au secours !"<<endl;
    if(ptSante<degats){//Evite les points de vie negatif et d'attaquer les morts
        ptSante=0;
    }
    else{
        ptSante-=degats;
    }
}

void Personnages::Attaque(Personnages &cible){

	cout << "A l'attaque !!!"<<endl;
}


void Personnages::Soigner(Personnages &cible){

	cout << "Pimpon !!!"<<endl;
}

void Personnages::recevoirSoin(int soin){

	if(ptSante<=0){//Evite que le personnage revienne à la vie
		cout<<"Je ne peux plus rien faire... il est mort"<<endl;
	}
	else{
		ptSante+=soin;
	}
	
}

//Fonction affichant les informations du personnage
void Personnages::printInfo(){
	cout << "Classe : "<< getClasse()<<endl;
	cout << "Nom : "<< getNom()<<endl;
	cout << "Sante : "<< getSante()<<endl;
	cout << "Distance : "<< getDistance()<<endl;
	cout << "PtSoin : "<< getPtSoin()<<endl;
	cout << "PtAttaque :"<< getPtAttaque()<<endl;
}

//On équipe le personnage d'un objet
void Personnages::equipeItem(Inventaire &item){

	ptSante+=item.getpV();  //Point de vie du personnage
	ptAttaque+=item.getpA(); //Point d'attaque
	ptSoin+=item.getpS(); //Point de Soin
	nomObjet=item.getNomItem();//On sauvegarde le nom de l'item
}
