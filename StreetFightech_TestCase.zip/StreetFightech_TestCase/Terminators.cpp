#include "Terminators.hh"

using namespace std;

Terminators::Terminators(string nom) : Guerriers(nom,"Terminators",rand()%11+80,35){//On entre son nom


}

Terminators::~Terminators(){
	
}

void Terminators::Attaque(Personnages &cible){

	if(getDistance()<20){//Si le terminator se trouve a une distance inferieure à 20
		cible.recevoirDegat(getPtAttaque());//On attaque
		cout<<"Asta la vista baby"<<endl;//Cri de guerre
	}
	else{
		cout<<"Tu as de la chance, tu es trop loin !!!"<<endl;//Cri de défaite si distance superieure à 20
		}
		setDistance(rand()%50+10);//On réinitialise la distance pour le prochain tour

}
