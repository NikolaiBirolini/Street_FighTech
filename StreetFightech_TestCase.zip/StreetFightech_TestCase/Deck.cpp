#include "Deck.hh"
#include <iostream>

using namespace std;

Deck::Deck(){
}

Deck::~Deck(){
	
}

void Deck::ajouterDeck(Personnages* cible){

	if(taille<5){
		Equipe.push_back(cible);
		taille++;
	}
	else{
		cout<<"Equipe complete"<<endl;
	}
}

void Deck::printDeck(){
	for(int i=0;i<5;i++){
		cout<<Equipe[i]<<endl;
	}

}
