#pragma once
#include <iostream>
#include <cstdlib>
#include "Guerriers.hh"

using namespace std;

class Terminators : public Guerriers {
//Classe personnage
public:
	Terminators(string nom);
	virtual ~Terminators();
	virtual void Attaque(Personnages &cible); 


protected:
	string classe = "Terminators";

};

