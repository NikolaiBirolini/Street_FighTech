#pragma once
#include <iostream>
#include <cstdlib>
#include "Soigneurs.hh"

using namespace std;
//Classe personnage
class Docteurs : public Soigneurs {

public:
	Docteurs(string nom);
	virtual ~Docteurs();
	virtual void Soigner(Personnages &cible); 


protected:
	string classe = "Docteurs";

};

