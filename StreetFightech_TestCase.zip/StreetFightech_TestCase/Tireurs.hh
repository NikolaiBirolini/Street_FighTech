#pragma once
#include <iostream>
#include <cstdlib>
#include "Guerriers.hh"

using namespace std;

class Tireurs : public Guerriers {
//Classe personnage
public:
	Tireurs(string nom);
	virtual ~Tireurs();
	virtual void Attaque(Personnages &cible); 

protected:
	string classe = "Tireurs";

};
