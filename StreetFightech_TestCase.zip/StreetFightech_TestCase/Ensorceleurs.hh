#pragma once
#include <iostream>
#include <cstdlib>
#include "Soigneurs.hh"

using namespace std;
//Classe personnage
class Ensorceleurs : public Soigneurs {

public:
	Ensorceleurs(string nom);
	virtual ~Ensorceleurs();
	virtual void Soigner(Personnages &cible); 


protected:
	string classe = "Ensorceleurs";

};

