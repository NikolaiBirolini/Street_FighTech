#pragma once
#include <iostream>
#include <cstdlib>
#include "Guerriers.hh"

using namespace std;
//Classe personnage
class Maudits : public Guerriers {

public:
	Maudits(string nom);
	virtual ~Maudits();
	//void virtual Attaque(Personnages &cible)const; 
	virtual void Attaque(Personnages &cible); 

protected:
	string classe = "Maudits";

};
