// Let Catch provide main():
#define CATCH_CONFIG_MAIN

#include "catch.hh"
#include <iostream>
#include "Terminators.hh"
#include "Tireurs.hh"
#include "Maudits.hh"
#include "Blindes.hh"
#include "AmasChair.hh"
#include "Automates.hh"
#include "Docteurs.hh"
#include "Ensorceleurs.hh"
#include "Nanites.hh"
#include "Famas.hh"
#include "Deck.hh"

using namespace std;

TEST_CASE("1: Création des personnages","Caracteristiques Communes"){

  Terminators* z = new Terminators("Jean Paul");
  Tireurs* a = new Tireurs("Mikasa");
  Maudits* b = new Maudits("Bob");
  Blindes* c = new Blindes("François");
  AmasChair* g = new AmasChair("Greg");
  Automates* h = new Automates("Cola");
  Docteurs* d= new Docteurs("Marc");
  Ensorceleurs* e= new Ensorceleurs("Tarpin");
  Nanites* f= new Nanites("Clarc");
  
  //Les classes sont elles bien crées ?
  REQUIRE(z->getClasse() == "Terminators");
  REQUIRE(a->getClasse() == "Tireurs");
  REQUIRE(b->getClasse() == "Maudits");
  REQUIRE(c->getClasse() == "Blindes");
  REQUIRE(d->getClasse() == "Docteurs");
  REQUIRE(e->getClasse() == "Ensorceleurs");
  REQUIRE(f->getClasse() == "Nanites");
  REQUIRE(g->getClasse() == "AmasChair");
  REQUIRE(h->getClasse() == "Automates");

  //Distance superieure à 10
  REQUIRE(z->getDistance() >= 10);
  REQUIRE(a->getDistance() >= 10);
  REQUIRE(b->getDistance() >= 10);
  REQUIRE(c->getDistance() >= 10);
  REQUIRE(d->getDistance() >= 10);
  REQUIRE(e->getDistance() >= 10);
  REQUIRE(f->getDistance() >= 10);
  REQUIRE(g->getDistance() >= 10);
  REQUIRE(h->getDistance() >= 10);

  //Distance inferieure à 60
  REQUIRE(z->getDistance() <= 60);
  REQUIRE(a->getDistance() <= 60);
  REQUIRE(b->getDistance() <= 60);
  REQUIRE(c->getDistance() <= 60);
  REQUIRE(d->getDistance() <= 60);
  REQUIRE(e->getDistance() <= 60);
  REQUIRE(f->getDistance() <= 60);
  REQUIRE(g->getDistance() <= 60);
  REQUIRE(h->getDistance() <= 60);  
  
  //On affiche tous les personnages
  cout<<z<<endl;
  cout<<a<<endl;
  cout<<b<<endl;
  cout<<c<<endl;
  cout<<g<<endl;
  cout<<h<<endl;
  cout<<d<<endl;
  cout<<e<<endl;
  cout<<f<<endl;
  

}

TEST_CASE("2: Personnages Guerriers","Pas de soin"){

  Terminators* z = new Terminators("Jean Paul");
  Tireurs* a = new Tireurs("Mikasa");
  Maudits* b = new Maudits("Bob");

  //Points de soin à 0
  REQUIRE(z->getPtSoin() == 0); 
  REQUIRE(a->getPtSoin() == 0); 
  REQUIRE(b->getPtSoin() == 0);

  //Points d'attaque > 0
  REQUIRE(z->getPtAttaque() > 0); 
  REQUIRE(a->getPtAttaque() > 0); 
  REQUIRE(b->getPtAttaque() > 0);   
}

TEST_CASE("3: Personnages Chevaliers","Pt de soin et pt Attaque"){

  Blindes* c = new Blindes("François");
  AmasChair* g = new AmasChair("Greg");
  Automates* h = new Automates("Cola");

  //Points soin > 0
  REQUIRE(c->getPtSoin() > 0); 
  REQUIRE(g->getPtSoin() > 0); 
  REQUIRE(h->getPtSoin() > 0);

  //Points d'attaque > 0
  REQUIRE(c->getPtAttaque() > 0); 
  REQUIRE(g->getPtAttaque() > 0); 
  REQUIRE(h->getPtAttaque() > 0);  
}

TEST_CASE("4: Personnages Soigneurs","Pas d'Attaque"){

  Docteurs* d= new Docteurs("Marc");
  Ensorceleurs* e= new Ensorceleurs("Tarpin");
  Nanites* f= new Nanites("Clarc");

  //Points Soin > 0
  REQUIRE(d->getPtSoin() > 0); 
  REQUIRE(e->getPtSoin() > 0); 
  REQUIRE(f->getPtSoin() > 0);

  //Points d'attaque = 0
  REQUIRE(d->getPtAttaque() == 0); 
  REQUIRE(e->getPtAttaque() == 0); 
  REQUIRE(f->getPtAttaque() == 0);  

}

TEST_CASE("5: Attaque","Soigner"){

  Terminators* z = new Terminators("Jean Paul");
  Tireurs* a = new Tireurs("Mikasa");
  Docteurs* d= new Docteurs("Marc");

  //On verifie si l'attaque a bien été réalisé, ctad si le nombre de point de vie enlevé est correct
  //On verifie aussi la fonction soigner, ctad si la vie du personnage après le soin est égal à points de vie + points de soin
  int attaquePoint = a->getPtAttaque();
  int santeDeF = z->getSante();
  
  a->Attaque((*z));
  
  cout<<z<<endl;
  
  REQUIRE(z->getSante()==(santeDeF-attaquePoint));
  
  cout<<z<<endl;

  santeDeF = z->getSante();

  d->Soigner(*(z));

  REQUIRE(z->getSante()>santeDeF);


}

TEST_CASE("6: Equiper"){

Terminators* z = new Terminators("Jean Paul");
Famas arme;

//Pour verifier si le famas est bien équipé, il faut que les points d'attaque du personnage augmentent de +10
//Il faut que la santé du personnage augmente de +15 (le +10 et le +15 sont des caractéristiques du famas)
int ptAttaqueSansArme = z->getPtAttaque();
int ptVieSansArme = z->getSante();
z->equipeItem(arme);
REQUIRE(z->getPtAttaque()==ptAttaqueSansArme+10);
REQUIRE(z->getSante()==ptVieSansArme+15);



}