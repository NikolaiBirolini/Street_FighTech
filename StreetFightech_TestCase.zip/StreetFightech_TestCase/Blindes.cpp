#include "Blindes.hh"

using namespace std;

Blindes::Blindes(string nom) : Tanks(nom,"Blindes",200,10,15){


}

Blindes::~Blindes(){
	
}

void Blindes::Attaque(Personnages &cible){
	cible.recevoirDegat(getPtAttaque());
	cout<<"Boom boom"<<endl;
}

void Blindes::Soigner(Personnages &cible){

	cout << "Heal !!!"<<endl;
	cible.recevoirSoin(getPtSoin());
}
