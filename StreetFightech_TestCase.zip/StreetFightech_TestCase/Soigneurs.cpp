#include "Soigneurs.hh"

using namespace std;

Soigneurs::Soigneurs(string nom, string classe, int Sante, int ptSoin) : Personnages(nom,classe,ptSoin,0,Sante){
	
}

Soigneurs::~Soigneurs(){
	
}

void Soigneurs::Attaquer(Personnages &cible){

	cout << "Impossible d'Attaquer"<<endl;
}
