#pragma once
#include <iostream>
#include <cstdlib>
#include "Famas.hh"

using namespace std;

class Personnages{

protected:
	
	string nom; //Stocke le nom du personnage
	string classe; //Indique la classe du personnage
	int ptSoin; //Point de Soin
	int ptAttaque; //Point d'attaque
	int ptSante;  //Point de vie du personnage
	int distance; //Distance à laquel se trouve le personnage
    bool arme=false;//Indique si le personnage possede une arme ou non
	string nomObjet;//Nom de l'arme posséder


public:
	Personnages(string nom, string classe, int ptSoin, int ptAttaque, int ptSante); //Constructeur
	virtual ~Personnages();//Destructeur
	
	//Getteurs
	int getSante() const {return ptSante;}
	int getDistance() const {return distance;}
	string getNom() const {return nom;}
	string getClasse() const {return classe;}
	int getPtAttaque() const {return ptAttaque;}
	int getPtSoin() const {return ptSoin;}
    bool getArme() const {return arme;}

    //Setteur
    void setArme(){arme=true;}
    void setDistance(int nouvDistance){distance=nouvDistance;}

    bool operator==(const Personnages &perso);//Surcharge de l'operateur == pour les tests
	friend ostream& operator<<(ostream& ,Personnages &cible);//Surcharge de l'operateur << pour afficher toutes les informations des personnages

	//Fonctions personnages
	virtual void Attaque(Personnages &cible); //Fonction virtuelle d'attaque 
	void recevoirDegat(int degats);//Fonction permettant de recevoir les degats
	virtual void Soigner(Personnages &cible); //Fonction virtuelle de soin
	void recevoirSoin(int soin);//Fonction permettant de recevoir les points de soin
	void printInfo();//Fonction pour print les information du personnage (utile avant la surcharge de <<)
	void equipeItem(Inventaire &item);//Fonction pour s'équiper d'une arme
};

inline ostream& operator<<(ostream& os , Personnages* cible)//Surcharge de l'opérateur <<
{
	os << "Classe : "<< cible->getClasse()<<endl;
	os << "Nom : "<< cible->getNom()<<endl;
	os << "Sante : "<< cible->getSante()<<endl;
	os << "Distance : "<< cible->getDistance()<<endl;
	os << "PtSoin : "<< cible->getPtSoin()<<endl;
	os << "PtAttaque :"<< cible->getPtAttaque()<<endl;
  	
  	return os;
 }

//Surcharge de l'opérateur ==
 inline bool Personnages::operator==(const Personnages &perso){
 	if (perso.getClasse()==getClasse()){
 		return 1;
 	}
 	else{
 		return 0;
 	}
 }
