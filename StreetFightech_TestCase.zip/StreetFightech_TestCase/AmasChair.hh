#pragma once
#include <iostream>
#include <cstdlib>
#include "Tanks.hh"

using namespace std;

//Classe personnage
class AmasChair : public Tanks {

public:
	AmasChair(string nom);
	virtual ~AmasChair();
	virtual void Attaque(Personnages &cible); 
	virtual void Soigner(Personnages &cible);

protected:
	string classe = "AmasChair";

};

