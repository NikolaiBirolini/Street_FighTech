#pragma once
#include <iostream>
#include <cstdlib>
//#include "Personnages.hh"
#include <string>
#include <vector>
#include "Terminators.hh"
#include "Tireurs.hh"
#include "Maudits.hh"
#include "Blindes.hh"
#include "Docteurs.hh"
#include "Ensorceleurs.hh"
#include "Nanites.hh"
#include "Famas.hh"
#include "Deck.hh"

using namespace std;

class Deck{

protected:
    vector<Personnages*> Equipe;
	int taille=0;

public:
	Deck();
	~Deck();

    void ajouterDeck(Personnages* cible);//Ajouter des personnages dans le deck, Equipe limité à 5 membres
    vector<Personnages*> getVecteur() {return Equipe;}//Retourner le deck stocké
    void printDeck();//Afficher les membres du deck

};
