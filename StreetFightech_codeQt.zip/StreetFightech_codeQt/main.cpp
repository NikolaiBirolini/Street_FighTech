#include "street_fightech.h"

#include <QApplication>
#include "../Terminators.hh"
#include "../Tireurs.hh"
#include "../Maudits.hh"
#include "../Blindes.hh"
#include "../Docteurs.hh"
#include "../Ensorceleurs.hh"
#include "../Nanites.hh"
#include "../Famas.hh"
#include "../Deck.hh"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Street_FighTech w;
    w.show();
     

    return a.exec();
}
