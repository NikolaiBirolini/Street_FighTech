#ifndef STREET_FIGHTECH_H
#define STREET_FIGHTECH_H

//Librairies de Qt
#include <QMainWindow>
#include <QtGui>
#include <QFont>
#include <QBrush>
#include <QPalette>
#include <QMediaPlayer>

//Librairie de nos classes pour le jeu
#include "../Terminators.hh"
#include "../Tireurs.hh"
#include "../Maudits.hh"
#include "../Blindes.hh"
#include "../Docteurs.hh"
#include "../Ensorceleurs.hh"
#include "../Nanites.hh"
#include "../Famas.hh"
#include "../Deck.hh"

QT_BEGIN_NAMESPACE
namespace Ui { class Street_FighTech; }
QT_END_NAMESPACE

class Street_FighTech : public QMainWindow
{
    Q_OBJECT

public:
    Street_FighTech(QWidget *parent = nullptr);
    ~Street_FighTech();

private slots:
    //Fonction permettant de gere l'evenement "bouton attaquer cliqué"
    void on_pushButtonATQ_clicked();

    //Fonction permettant de gere l'evenement "bouton soigner cliqué"
    void on_pushButtonSoign_clicked();

    //Fonction permettant de gere l'evenement "iteme selectionné dans la liste 1"
    void on_listWidget_itemSelectionChanged();

    //Fonction permettant de gere l'evenement "iteme selectionné dans la liste 2"
    void on_listWidget_2_itemSelectionChanged();

    //Checkboxes pour définir les blessés dans l'équipe 1, true : blessé, false : non blessé
    void on_checkBox_clicked(bool checked);
    void on_checkBox_2_clicked(bool checked);
    void on_checkBox_3_clicked(bool checked);
    void on_checkBox_5_clicked(bool checked);
    void on_checkBox_6_clicked(bool checked);

    //Checkboxes pour définir les blessés dans l'équipe 2, true : blessé, false : non blessé
    void on_checkBox_7_clicked(bool checked);
    void on_checkBox_10_clicked(bool checked);
    void on_checkBox_4_clicked(bool checked);
    void on_checkBox_8_clicked(bool checked);
    void on_checkBox_9_clicked(bool checked);

    //Fonction permettant de gerer l'évenement le bouton équiper cliqué
    void on_pushButton_clicked();

    //Checkboxes servant à définir si les équipes sont prêtes ou non, true : prête, false : non prête
    void on_checkBox_11_clicked(bool checked);//Equipe 1
    void on_checkBox_12_clicked(bool checked);//Equipe 2

private:
    Ui::Street_FighTech *ui;
    vector<Personnages*> Equipe;//Vecteur contenant les pointeurs des personnages de l'équipe 1
    vector<Personnages*> Equipe2;//Vecteur contenant les pointeurs des personnages de l'équipe 2
    vector<Inventaire*> Items;//Vecteur contenant les intemes disponibles dans l'inventaire
    bool a,b,c,d,e,f,g,h,i,j;//Booléens (de a à e état des personnages de l'équipe 1 (cible pour soin ou non)
    //(de f à jétat des personnages de l'équipe 2)
    bool pret1=false;
    bool pret2=false;//pret1 et pret2, état des équipes
    int indexe;//indexe du blessé sélectionné dans l'équipe 1
    int indexe2;//indexe du blessé sélectionné dans l'équipe 2

    QMediaPlayer* player;
};
#endif // STREET_FIGHTECH_H
