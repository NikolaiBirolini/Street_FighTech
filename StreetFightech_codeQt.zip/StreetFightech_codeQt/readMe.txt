Dans ce .zip, vous trouverez :

- StreetFighTech.h : Header de la fenêtre
- StreetFighTech.cpp : Code cpp de la fenêtre
- main.cpp : Code cpp lançant la fenêtre
- bgsound.mp3 : Musique de fond