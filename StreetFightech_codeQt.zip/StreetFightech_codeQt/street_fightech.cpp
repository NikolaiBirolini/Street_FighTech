#include "street_fightech.h"
#include "ui_street_fightech.h"

Street_FighTech::Street_FighTech(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Street_FighTech)
{
    //Création des personnages
    Terminators* k=new Terminators("Mikasa");
    Tireurs* b=new Tireurs("Jean");
    Maudits* c=new Maudits("Eren");
    Nanites* h=new Nanites("Historia");
    Terminators* e=new Terminators("Erwin");

    //Création item inventaire
    Famas* arme=new Famas();

    //Son Background
    player = new QMediaPlayer(this);
    player->setMedia(QUrl::fromLocalFile("/home/niko/Desktop/ProjC++/sound/bgsound.mp3"));
    player->play();

    //Création du deck de l'équipe1
    Deck deck1;

    //Ajout des personnage de l'équipe 1 dans le deck
    deck1.ajouterDeck(k);
    deck1.ajouterDeck(b);
    deck1.ajouterDeck(c);
    deck1.ajouterDeck(h);
    deck1.ajouterDeck(e);

    ui->setupUi(this); //Constructeur de la fenetre principale
    setWindowTitle("Street FighTech");//Titre de la fenetre principale
    setFixedSize(720,450);//Taille de la fenêtre principale

    //Personnalisation des couleurs des boutons
    ui->pushButtonQ->setStyleSheet("background-color: orange");
    ui->pushButtonATQ->setStyleSheet("background-color: red");
    ui->pushButtonSoign->setStyleSheet("background-color: green");
    ui->pushButton->setStyleSheet("background-color: blue");

    //Initialisation des labels
    ui->label_2->setText("0");
    ui->label_3->setText("");
    ui->label_4->setText("");
    ui->label_8->setText("Préparez vous à combattre !");
    ui->label_7->setText("C'est à l'équipe 1 de jouer !");
    ui->label_8->setAlignment(Qt::AlignCenter);
    ui->label_7->setAlignment(Qt::AlignCenter);

    //Initialisation de la police d'écriture
    QFont myFont("Arial");
    myFont.setPointSize(14);

    //Mise en place de la police d'acriture dans les deux listes d'équipe
    ui->listWidget->setFont(myFont);
    ui->listWidget_2->setFont(myFont);

    //Remplissage des listes des équipes
    for (int i = 0; i<5;i++){
    ui->listWidget->addItem(QString::fromStdString(deck1.getVecteur()[i]->getNom()));
    }
    Equipe=deck1.getVecteur();//Sauvegarde du deck de l'équipe 1 dans la fenetre principale (classe : street_fightech.hh)

    //Initialisation des personnages de l'équipe 2
    Docteurs* f=new Docteurs("Bertolto");
    Maudits* j=new Maudits("Richard");
    Nanites* z=new Nanites("Eugene");
    Terminators* l=new Terminators("Marie");
    Ensorceleurs* g=new Ensorceleurs("Annie");

    Deck deck2;//Création du deck de la 2eme équipe

    //Ajout des personnages de l'équipe 2 dans le deck numero 2
    deck2.ajouterDeck(f);
    deck2.ajouterDeck(j);
    deck2.ajouterDeck(z);
    deck2.ajouterDeck(l);
    deck2.ajouterDeck(g);

    //Remplissage de la liste de l'équipe 2
    for (int i = 0; i<5;i++){
    ui->listWidget_2->addItem(QString::fromStdString(deck2.getVecteur()[i]->getNom()));
    }
    Equipe2=deck2.getVecteur();//Sauvegarde du deck de l'équipe 2 dans la fenetre principale (classe : street_fightech.hh)

    //Initialisation des listes d'inventaire
     ui->listWidget_3->addItem(QString::fromStdString(arme->getNomItem()));
     ui->listWidget_4->addItem(QString::fromStdString(arme->getNomItem()));

     //Sauvegarde de (ou des) iteme(s) dans un vecteur<itemes*> dans la classe : street_fightech
     Items.push_back(arme);


}

//Destructeur de la fenêtre
Street_FighTech::~Street_FighTech()
{
    delete ui;
}

//Fonction gerant l'évenement "Bouton d'attaque cliqué"
void Street_FighTech::on_pushButtonATQ_clicked()
{
    //Le joueur ne peut commencer la partie qu'en attaquant
    static int x=0;//Initialisation du compteur de tour
    if (x==0){//Si l'attaque est la premiere action de la partie
    x++;//On incremente de 1 le nombre de tours
    ui->label_2->setText(QString::number(x));//On affiche le nombre de tours
    }
    else{//Sinon, on lit d'abord la valeur dans le label puis on l'incremente
        QString var=ui->label_2->text();//Lecture de la valeur
        int temp=var.toInt();//Conversion en entier
        temp++;//Incrementation
        ui->label_2->setText(QString::number(temp));//Affichage de la valeur
    }

    if(ui->listWidget->currentItem() && ui->listWidget_2->currentItem()){//Si un personnage est sélectionné dans la liste de l'équipe 1 et un autre dans la liste de l'équipe 2
        if(ui->label_2->text().toInt()%2){//Si le tours est paire
            ui->label_7->setText("C'est à l'équipe 2 de jouer !");//On indique à l'équipe 2 de jouer le prochain coup

            //Ici nous allons chercher les indexes des deux listes
            QString str = ui->listWidget->currentItem()->text();//On recupere le nom du personnage selectionnné dans l'équipe 1
            QString str2 = ui->listWidget_2->currentItem()->text();//On recupere le nom du personnage selectionné dans l'équipe 2
            for (int i = 0; i<5;i++){//On recherche d'abord dans la premiere liste
              if(str == QString::fromStdString(Equipe[i]->getNom())){
                    for(int j = 0; j<5;j++){//Une fois que le premier indexe a été trouvé, on cherche celui de la liste 2
                        if(str2==QString::fromStdString(Equipe2[j]->getNom())){
                            if(Equipe[i]->getSante()!=0){//Si les points de vie de l'attaquant ne sont pas nulles
                                if(Equipe2[j]->getSante()!=0){//Si la cible n'est pas déja morte
                                    Equipe[i]->Attaque(*(Equipe2[j]));//Alors le personnage de l'équipe1 attaque le personnage de l'équipe 2
                                    ui->label_8->setText(QString::fromStdString(Equipe[i]->getNom()+" attaque "+Equipe2[j]->getNom()));//On indique aux joueurs dans le label quel personnage attaque quel personnage

                                }
                                else{//Sinon, on lui indique que l'attaque n'a pas pu être réalisée, ici l'attaquant n'a pas de vie
                                    ui->label_8->setText(QString::fromStdString(Equipe2[j]->getNom()+" ne peut pas être attaquée"));
                                }
                            }
                            else{//Si la cible n'a pas de vie, on l'indique aux joueurs
                                ui->label_8->setText(QString::fromStdString(Equipe[i]->getNom()+" ne peut pas attaquer"));
                            }

                        }
                    }
                }

              }
        }
        else{//Lorsque c'est le tours de l'équipe 2
            ui->label_7->setText("C'est à l'équipe 1 de jouer !");//On indique que le prochain coup doit être joué par l'équipe 1
            QString str = ui->listWidget->currentItem()->text();//On recupere le nom du personnage selectionné dans la liste 1
            QString str2 = ui->listWidget_2->currentItem()->text();//On recupere le nom du personnage selectionné dans la liste 2
            for (int i = 0; i<5;i++){//On recherche les deux inedxes
              if(str == QString::fromStdString(Equipe[i]->getNom())){//On trouve l'indexe de la victime dans l'équipe 1
                    for(int j = 0; j<5;j++){//On cherche le deuxieme indexe
                        if(str2==QString::fromStdString(Equipe2[j]->getNom())){//On trouve le deuxieme indexe, celui de l'attaquant
                            if(Equipe2[j]->getSante()!=0){//Si l'attaquant a toute sa vie
                                if(Equipe[i]->getSante()!=0){//SI la cible a toute sa vie
                                    Equipe2[j]->Attaque(*(Equipe[i]));//Le personnage de l'équipe 2 attaque le personnage de l'équipe 1
                                    //On indique aux joueurs l'attaque
                                    ui->label_8->setText(QString::fromStdString(Equipe2[j]->getNom()+" attaque "+Equipe[i]->getNom()));
                                }
                                else{//Si la cible n'a pas de santé, on l'indique aux joueurs
                                    ui->label_8->setText(QString::fromStdString(Equipe[i]->getNom()+" ne peut pas être attaquée"));
                                }

                            }
                            else{//Si l'attaquant n'a pas de santé, on l'indique aux joueurs
                                ui->label_8->setText(QString::fromStdString(Equipe2[j]->getNom()+" ne peut pas attaquer"));
                            }

                        }
                    }
                }

              }
        }
    }
        //Conditions de victoire
        //Si tous les joueurs de l'équipe 1 n'ont plus de point de vie, alors l'équipe 2 gagne et on l'indique aux joueurs
        if((Equipe[0]->getSante()==0)&&(Equipe[1]->getSante()==0)&&(Equipe[2]->getSante()==0)&&(Equipe[3]->getSante()==0)&&(Equipe[4]->getSante()==0)){
            ui->label_8->setText("L'équipe 2 a gagné !!!!!!!!");
        }//Sinon, c'est l'équipe 1 qui gagne
        else if((Equipe2[0]->getSante()==0)&&(Equipe2[1]->getSante()==0)&&(Equipe2[2]->getSante()==0)&&(Equipe2[3]->getSante()==0)&&(Equipe2[4]->getSante()==0)){
            ui->label_8->setText("L'équipe 1 a gagné !!!!!!!!");
        }

}

//Fonction gerant l'évenement : Bouton soin cliqué
void Street_FighTech::on_pushButtonSoign_clicked()
{
    QString var=ui->label_2->text();//On recupere le nombre de tour
    int temp=var.toInt();//On le convertit en entier
    temp++;//On l'incremente
    ui->label_2->setText(QString::number(temp));//On l'affiche
    if(ui->label_2->text().toInt()%2){//Si c'est à l'équipe 1 de jouer
    if((a||b||c||d||e)&&(ui->listWidget->currentItem())){//Si un soigneur et un blessé ont été sélectionné
            for (int i=0;i<5;i++){//On recherche l'indexe du soigneur
                if(ui->listWidget->currentItem()->text()==QString::fromStdString(Equipe[i]->getNom())){//Dès que l'indexe est trouvé
                    Equipe[i]->Soigner(*(Equipe[indexe]));//Le soigneur remonte les points de vie de la cible
                    }
               }
        }
        else{
            ui->label_8->setText("Impossible de soigner\nAucune cible sélectionnée");//Si aucun soigneur ou blessé sélectionnés, on l'indique aux joueurs
        }
    }//Si c'est à l'équipe 2 de jouer
    else if((f||g||h||i||j)&&(ui->listWidget_2->currentItem())){//Si un soigneur et un blessé ont été sélectionné
        for (int i=0;i<5;i++){//On recherche l'indexe du soigneur
            if(ui->listWidget_2->currentItem()->text()==QString::fromStdString(Equipe2[i]->getNom())){//Lorsque l'indexe est trouvé
                Equipe2[i]->Soigner(*(Equipe2[indexe2]));//Le soigneur remonte les points de vie de la cible
                }
           }
    }
    //On réinitialise les checkbox (true=blessé)
    ui->checkBox_2->setChecked(false);
    ui->checkBox->setChecked(false);
    ui->checkBox_3->setChecked(false);
    ui->checkBox_4->setChecked(false);
    ui->checkBox_5->setChecked(false);
    ui->checkBox_6->setChecked(false);
    ui->checkBox_7->setChecked(false);
    ui->checkBox_8->setChecked(false);
    ui->checkBox_9->setChecked(false);
    ui->checkBox_10->setChecked(false);

}


//Fonction gerant la selection d'un personnage de l'équipe 1 dans la liste 1
void Street_FighTech::on_listWidget_itemSelectionChanged()
{
    QString str = ui->listWidget->currentItem()->text();//On recupere le nom du personnage selectionné
    for (int i = 0; i<5;i++){//On recherche son indexe
      if(str == QString::fromStdString(Equipe[i]->getNom())){//on trouve son indexe
          ui->label_3->setText((QString::fromStdString(Equipe[i]->getNom()))+"\n"+QString::fromStdString(Equipe[i]->getClasse())+"\n"+"Pv : "+QString::number(Equipe[i]->getSante())+"\n"+"Pa : "+QString::number(Equipe[i]->getPtAttaque())+"\n"+"Ps : "+QString::number(Equipe[i]->getPtSoin())+"\n"+"D : "+QString::number(Equipe[i]->getDistance()));
      }//On affiche dans un label, toutes les informations du personnages
    }

}
//Fonction gerant la selection d'un personnage de l'équipe 2 dans la liste 2
void Street_FighTech::on_listWidget_2_itemSelectionChanged()
{
    QString str = ui->listWidget_2->currentItem()->text();//On recupere le nom du personnage selectionné
    for (int i = 0; i<5;i++){//On cherche son indexe
      if(str == QString::fromStdString(Equipe2[i]->getNom())){//on trouve son indexe
          ui->label_4->setText((QString::fromStdString(Equipe2[i]->getNom()))+"\n"+QString::fromStdString(Equipe2[i]->getClasse())+"\n"+"Pv : "+QString::number(Equipe2[i]->getSante())+"\n"+"Pa : "+QString::number(Equipe2[i]->getPtAttaque())+"\n"+"Ps : "+QString::number(Equipe2[i]->getPtSoin())+"\n"+"D : "+QString::number(Equipe2[i]->getDistance()));
      }//On affiche sur un label, toutes les informations du personnage sélectionné
    }
}

//Gestion des checkboxes dans la liste 1 de l'équipe 1
//Ils servent à sélectionner les blessés
void Street_FighTech::on_checkBox_clicked(bool checked)
{
    a=checked;//On sauvegarde sa valeur booléenne
    indexe=0;//On lui associe l'indexe 0 qui correspond à l'indexe du premier personnage dans la liste 1 de l'équipe 1
}

void Street_FighTech::on_checkBox_2_clicked(bool checked)
{
    b=checked;
    indexe=1;
}

void Street_FighTech::on_checkBox_3_clicked(bool checked)
{
    c=checked;
    indexe=2;
}

void Street_FighTech::on_checkBox_5_clicked(bool checked)
{
    d=checked;
    indexe=3;
}

void Street_FighTech::on_checkBox_6_clicked(bool checked)
{
    e=checked;
    indexe=4;
}
//Gestion des checkboxes dans la liste 2 de l'équipe 2
//Ils servent à sélectionner les blessés
void Street_FighTech::on_checkBox_7_clicked(bool checked)
{
    f=checked;//On sauvegarde sa valeur booléenne
    indexe2=0;//On lui associe un indexe qui correspond ici, au premier personnage de la liste 2 de l'équipe 2
}

void Street_FighTech::on_checkBox_10_clicked(bool checked)
{
    g=checked;
    indexe2=1;
}

void Street_FighTech::on_checkBox_4_clicked(bool checked)
{
    h=checked;
    indexe2=2;
}

void Street_FighTech::on_checkBox_8_clicked(bool checked)
{
    i=checked;
    indexe2=3;
}

void Street_FighTech::on_checkBox_9_clicked(bool checked)
{
    j=checked;
    indexe2=4;
}

//Cette fonction gere l'envenement : Bouton equiper cliqué
//Attention, on ne peut s'équiper que pendant le tours 0
void Street_FighTech::on_pushButton_clicked()
{
    QString var=ui->label_2->text();//On recupere le nombre de tours
    int temp=var.toInt();//On le convertit en entier

    if(temp==0){//Si le nombre de tours = 0
        //Equipement Equipe 1
        ui->label_8->setText(ui->listWidget_3->currentItem()->text());
        cout<<pret1<<endl;
        if(ui->listWidget_3->currentItem()&&(pret1==0)){//Si un item est sélectionné dans la liste d'item et que l'équipe 1 n'est pas prête
            if(ui->listWidget->currentItem()){//Si un personnage dans la liste 1 de l'équipe 1 est sélectionné
                QString str = ui->listWidget->currentItem()->text();//On recupere son nom
                for (int i = 0; i<5;i++){//On recherche son indexe
                  if(str == QString::fromStdString(Equipe[i]->getNom())){//On trouve son indexe
                      if(Equipe[i]->getArme()==0){//Si le personnage ne possede aucun iteme
                          Equipe[i]->equipeItem(*(Items[0])); //On équipe le personnage
                          Equipe[i]->setArme();//On indique dans sa classe qu'il est équipé d'un iteme
                      }
                      else{//Sinon, on indique aux joueurs que le personnage est déjà équipé
                          ui->label_8->setText("Personnage déja équipé");
                      }

                  }
            }
            }
            else{//Sinon on indique à l'utilisateur de sélectionner un personnage
                ui->label_8->setText("Sélectionnez un personnage");
            }
        }
        //Equipement Equipe 2
        else if (ui->listWidget_4->currentItem()&&(pret2==0)){//Si un item est sélectionné et que l'équipe 2 n'est pas prête
            if(ui->listWidget_2->currentItem()){//Si un personnage de l'équpe 2 est sélectionné
                QString str = ui->listWidget_2->currentItem()->text();//On recupere le nom du personnage
                for (int i = 0; i<5;i++){//on cherche son indexe
                    if(str == QString::fromStdString(Equipe2[i]->getNom())){//On trouve sons indexe
                        if(Equipe2[i]->getArme()==0){//Si le personnage n'a pas d'item
                            Equipe2[i]->equipeItem(*(Items[0]));//Le personnage est équipé d'un iteme
                            Equipe2[i]->setArme();//On indique dans sa classe que le personnage possede un iteme
                        }
                        else{//Sinon on indique que le personnage est déjà équipé
                            ui->label_8->setText("Personnage déja équipé");
                        }
                }
                }

            }
            else{//Sinon on indique aux joueurs de sélectionner un personnage
                ui->label_8->setText("Sélectionnez un personnage");
            }

        }
        else{//Sinon on indique aux joueurs de selectionner un iteme
            //ui->label_8->setText("Sélectionnez un item");
        }

    }
    else{//Si le tours n'est pas égal à 0, on indique aux joueurs que c'est trop tard
        ui->label_8->setText("Equipement possible seulement \n endébut de partie");
    }
}

//Fonction gérant l'évenement : Le joueur 1 coche la checkboxe prêt de l'équipe 1
void Street_FighTech::on_checkBox_11_clicked(bool checked)
{
    pret1=checked;//On sauvegarde le bool dans la classe de la fenêtre pour le bouton équiper
    ui->listWidget_3->setVisible(false);//On fait disparaitre la liste d'iteme
    ui->checkBox_11->setVisible(false);//On fait disparaitre le bouton pret pour l'équipe 1
    ui->label_9->setVisible(false);//On fait disparaitre le label "inventaire"
}

//Fonction gérant l'évenement : Le joueur 2 coche la checkboxe prêt de l'équipe 2
void Street_FighTech::on_checkBox_12_clicked(bool checked)
{
    pret2=checked;
    ui->listWidget_4->setVisible(false);//On sauvegarde le bool dans la classe de la fenêtre pour le bouton équiper
    ui->checkBox_12->setVisible(false);//On fait disparaitre la liste d'iteme pour l'équipe 2
    ui->label_10->setVisible(false);//On fait disparaitre le bouton pret pour l'équipe 2
    ui->label_8->setText("Que le jeu commence !");//on indique aux joueurs que la partie peut commencer
}
